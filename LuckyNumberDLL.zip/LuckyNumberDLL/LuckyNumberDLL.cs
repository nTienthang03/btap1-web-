﻿using System;

namespace LuckyNumberDLL
{
    public class LuckyNumberCalculator
    {
        private string name;
        private DateTime birthDate;
        private const int PERSONAL_CONSTANT = 42; // Dấu ấn cá nhân: 42 từ Hitchhiker's Guide

        public string Name
        {
            get { return name; }
            set { name = value ?? string.Empty; }
        }

        public DateTime BirthDate
        {
            get { return birthDate; }
            set { birthDate = value; }
        }

        public int CalculateLuckyNumber()
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("Ten Khong duoc rong.");

            string combined = name + birthDate.ToString("yyyyMMdd");
            int hash = combined.GetHashCode();
            int luckyNumber = Math.Abs(hash) * PERSONAL_CONSTANT;
            return luckyNumber;
        }

        public string GetLuckyMessage()
        {
            int lucky = CalculateLuckyNumber();
            return string.Format("So may man cua toi  {0} la {1}, chuc ban may man theo phong cach vu tru ", name, lucky);
        }
    }
}