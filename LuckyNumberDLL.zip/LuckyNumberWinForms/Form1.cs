﻿using System;
using System.Windows.Forms;
using LuckyNumberDLL;

namespace LuckyNumberWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); // giữ Designer
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            DateTime birthDate = dtpBirthDate.Value;

            if (string.IsNullOrEmpty(name))
            {
                lblResult.Text = "⚠️ Vui lòng nhập tên!";
                return;
            }

            try
            {
                LuckyNumberCalculator calc = new LuckyNumberCalculator
                {
                    Name = name,
                    BirthDate = birthDate
                };

                string message = calc.GetLuckyMessage();
                lblResult.Text = $"{message}\n✨ Bí mật vũ trụ: x42!";
            }
            catch (Exception ex)
            {
                lblResult.Text = "❌ Lỗi: " + ex.Message;
            }
        }
    }
}
