﻿using System;
using LuckyNumberDLL;

public partial class api : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.QueryString["name"];
        string birthStr = Request.QueryString["birth"];

        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(birthStr))
        {
            Response.Write("⚠️ Thiếu thông tin đầu vào!");
            return;
        }

        try
        {
            DateTime birthDate = DateTime.Parse(birthStr);

            LuckyNumberCalculator calc = new LuckyNumberCalculator
            {
                Name = name,
                BirthDate = birthDate
            };

            string msg = calc.GetLuckyMessage();
            Response.Write("<h2>" + msg + "</h2>");
        }
        catch (Exception ex)
        {
            Response.Write("❌ Lỗi: " + ex.Message);
        }
    }
}
